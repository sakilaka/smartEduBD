<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;

class ParentMenuController extends Controller
{
    public function acadmic()
    {
        return view('layouts.backend_app');
    }
    public function systems()
    {
        return view('layouts.backend_app');
    }
    public function smsSystems()
    {
        return view('layouts.backend_app');
    }
    public function content()
    {
        return view('layouts.backend_app');
    }
    public function galleryImages()
    {
        return view('layouts.backend_app');
    }
    public function websiteOthers()
    {
        return view('layouts.backend_app');
    }
    public function schoolStudent()
    {
        return view('layouts.backend_app');
    }
    public function attendance()
    {
        return view('layouts.backend_app');
    }
    public function cardManagement()
    {
        return view('layouts.backend_app');
    }
    public function studentPayments()
    {
        return view('layouts.backend_app');
    }
    public function primaryResult()
    {
        return view('layouts.backend_app');
    }
    public function secondaryResult()
    {
        return view('layouts.backend_app');
    }
}
