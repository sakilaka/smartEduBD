<?php

/**
 * @Oshit Sutra Dhar
 */

namespace App\Models\Website\Content;

use App\Models\Base\BaseModel;

class ContentFile extends BaseModel {

    protected $guarded        = ['id'];
    protected static $logName = 'Content File';
}
