<?php

/**
 * @OSHIT SUTRA DHAR
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AcademicClassMapping extends Model
{
    public $timestamps = false;
    protected $guarded = ['id'];
}
