<template>
  <div v-if="$root.tableSpinner" class="text-center my-2">
    <span
      style="height: 1.2rem; width: 1.2rem; font-size: 11px"
      class="spinner-border text-success"
    ></span>
  </div>
</template>