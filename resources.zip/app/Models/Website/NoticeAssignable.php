<?php

/**
 * @OSHIT SUTRA DHAR
 */

namespace App\Models\Website;

use Illuminate\Database\Eloquent\Model;

class NoticeAssignable extends Model
{
    protected $guarded = ['id'];

    public $timestamps = false;
}
