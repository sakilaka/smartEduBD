<?php

/**
 * @OSHIT SUTRA DHAR
 */

namespace App\Models\MasterSetup;

use App\Models\Base\BaseModel;

class AccountHead extends BaseModel
{
    protected $guarded = ['id'];

    protected static $logName = 'Account Head';
}
