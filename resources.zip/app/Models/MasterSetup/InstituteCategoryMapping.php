<?php

/**
 * @OSHIT SUTRA DHAR
 */

namespace App\Models\MasterSetup;

use App\Models\Base\BaseModel;

class InstituteCategoryMapping extends BaseModel
{
    protected $guarded = ['id'];

    protected static $logName = "InstituteCategoryMapping";
}
