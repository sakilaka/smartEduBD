<?php

/**
 * @OSHIT SUTRA DHAR
 */

namespace App\Models\Result;

use App\Models\Base\BaseModel;

class SecondaryGradeManagement extends BaseModel
{
    protected $guarded = ['id'];

    protected static $logName = "Secondary Grade Management";
}
