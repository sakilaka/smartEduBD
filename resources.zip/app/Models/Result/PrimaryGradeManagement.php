<?php

/**
 * @OSHIT SUTRA DHAR
 */

namespace App\Models\Result;

use App\Models\Base\BaseModel;

class PrimaryGradeManagement extends BaseModel
{
    protected $guarded = ['id'];

    protected static $logName = "Primary Grade Management";
}
